/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ForumServlet.GuiWspolne;

import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author jasyn
 */
public interface GuiElement
{
     String getHtml(HttpServletRequest request);
}
