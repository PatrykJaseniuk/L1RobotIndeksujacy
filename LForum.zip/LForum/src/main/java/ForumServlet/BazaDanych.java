/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ForumServlet;

/**
 *
 * @author jasyn
 */
class BazaDanych
{

    BazaDanych(String jdbcmysqllocalhost3306testserverTimezoneU, String root, String admin)
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
