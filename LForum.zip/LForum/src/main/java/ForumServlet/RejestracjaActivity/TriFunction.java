/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ForumServlet.RejestracjaActivity;

/**
 *
 * @author jasyn
 */
public interface TriFunction<Arg1, Arg2,Arg3,Return>
{
    Return apply(Arg1 arg1, Arg2 arg2, Arg3 arg3);
}
